import { SignIn } from "./sign-in.js";
/// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getDatabase, set, ref } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";
import { getAuth, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

export class SignUp {
    render() {
        const firebaseConfig = {
            apiKey: "AIzaSyBsG4juRDaBwFwuABPTXbavgyIkq0hkHaU",
            authDomain: "kimo-36593.firebaseapp.com",
            databaseURL: "https://kimo-36593-default-rtdb.asia-southeast1.firebasedatabase.app",
            projectId: "kimo-36593",
            storageBucket: "kimo-36593.appspot.com",
            messagingSenderId: "778449637560",
            appId: "1:778449637560:web:94acb9b6982bbd7fb3644d",
            measurementId: "G-PB3QSNVEND"
          };
        // Initialize Firebase
        const app = initializeApp(firebaseConfig);
        const database = getDatabase(app);
        const auth = getAuth();

        let renderForm = document.getElementById('render');
        renderForm.innerHTML = '';
        renderForm.innerHTML = ` <div class="glitch-wrapper2">
		<div class="glitch2" data-text="SIGN UP_">SIGN UP_</div>
		<div class="glitch2" data-text="SIGN UP_">SIGN UP_</div>
		<div class="glitch2" data-text="SIGN UP_">SIGN UP_</div>
		<div class="glitch2" data-text="SIGN UP_">SIGN UP_</div>
		<div class="glitch2" data-text="SIGN UP_">SIGN UP_</div>
		<div class="glitch2" data-text="SIGN UP_">SIGN UP_</div>

	 </div>
	<div style="text-align: center; margin-left: 35%; margin-top: 5%;">
		<div class="form-group row ">
			<label for="basic-addon1" class="col-sm-2 col-form-label" style="color: aliceblue;">Email</label>
			<div class="col-sm-10">
			  <input type="email" class="form-control w-25" id="email" placeholder="email@example.com">
			</div>
		  </div>
		  
		  <br>
		  <div class="form-group row ">
			<label for="basic-addon1" class="col-sm-2 col-form-label" style="color: aliceblue;">username</label>
			<div class="col-sm-10">
			  <input type="text" class="form-control w-25" id="username" placeholder="type your username">
			</div>
		  </div>
<br>
		<div class="form-group row ">
		  <label for="inputPassword" class="col-sm-2 col-form-label" style="color: aliceblue;">Password</label>
		  <div class="col-sm-10">
			<input type="password" class="form-control w-25" id="pass" placeholder="Password">
		  </div>
		</div>
		
		<br>
		<button id="sign-up">Sign up</button>
		<br>
		<p id="ro-sign-in" style="color: lightseagreen;">Sign in</p>
	  </div>

            `
        document.getElementById('ro-sign-in').addEventListener('click', () => {
            let signin = new SignIn();
            signin.render();
        });
        document.getElementById('sign-up').addEventListener("click", () => {
            let email = document.getElementById('email').value;
            let password = document.getElementById('pass').value;
            let username = document.getElementById('username').value;
            createUserWithEmailAndPassword(auth, email, password)
                .then((userCredential) => {
                    // Signed in 
                    const user = userCredential.user;
                    
                    set(ref(database, 'users/' + user.uid),{
                        username: username,
                        email: email,
                        password: password
                    });
                    alert('The account have been created');
                    document.getElementById('email').value 
                    = document.getElementById('pass').value 
                    = document.getElementById('username').value = '';
                })
                .catch((error) => {
                    const errorCode = error.code;
                    const errorMessage = error.message;
                    alert(errorMessage);
                });
        })
    }
}