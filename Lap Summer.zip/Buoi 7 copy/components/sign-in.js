import { SignUp } from "./sign-up.js";

// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getDatabase, set, ref, get } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

export class SignIn {
    render() {
        const firebaseConfig = {
            apiKey: "AIzaSyBsG4juRDaBwFwuABPTXbavgyIkq0hkHaU",
            authDomain: "kimo-36593.firebaseapp.com",
            databaseURL: "https://kimo-36593-default-rtdb.asia-southeast1.firebasedatabase.app",
            projectId: "kimo-36593",
            storageBucket: "kimo-36593.appspot.com",
            messagingSenderId: "778449637560",
            appId: "1:778449637560:web:94acb9b6982bbd7fb3644d",
            measurementId: "G-PB3QSNVEND"
        };

        // Initialize Firebase
        const app = initializeApp(firebaseConfig);
        const database = getDatabase(app);
        const auth = getAuth();

        let renderForm = document.getElementById('render');
        renderForm.innerHTML = '';
        renderForm.innerHTML = ` <div class="wrapper">
		<svg>
			<text x="50%" y="50%" dy=".35em" text-anchor="middle">
				login
			</text>
		</svg>
	</div>
	<div style="text-align: center; margin-left: 35%; margin-top: 5%;">
		<div class="form-group row ">
			<label for="basic-addon1" class="col-sm-2 col-form-label" style="color: aliceblue;">Email</label>
			<div class="col-sm-10">
			  <input type="email" class="form-control w-25" id="email" placeholder="email@example.com">
			</div>
		  </div>
          <br>
		<div class="form-group row ">
		  <label for="inputPassword" class="col-sm-2 col-form-label" style="color: aliceblue;">Password</label>
		  <div class="col-sm-10">
			<input type="password" class="form-control w-25" id="pass" placeholder="Password">
		  </div>
		</div>
		<br>
		<button id="sign-in" class="btn btn-primary mb-2" style="margin-left: -500px;">login</button>
		<br>
		<p id="ro-sign-up" style="color: lightseagreen ">Sign up</p>
	  </div>`
        document.getElementById('ro-sign-up').addEventListener('click', () => {
            let signup = new SignUp();
            signup.render();
        });
        document.getElementById('sign-in').addEventListener('click', () => {
            let email = document.getElementById('email').value;
            let pw = document.getElementById('pass').value;
            signInWithEmailAndPassword(auth, email, pw)
                .then((userCredential) => {
                    // Signed in 
                   const user = userCredential.user;
                   const usersRef = ref(database, 'users/' + user.uid);
                  
                    //// 259200000 = ngay
                   get(usersRef)
                   .then((snap) => {
                        if(snap.exists()){
                            const now = Date.now();
                            let expTime = new Date(now);
                            expTime.setDate(expTime.getDate() + 3);
                            let token = {
                                userName : snap.val().username,
                                email: snap.val().email,
                                expTime: expTime.setDate(expTime.getDate() + 3)
                            }///let sha256 = new SHA256();
                            let tokenCry = JSON.stringify(token)
                            localStorage.setItem('Auth', tokenCry);
                            location.href = './page/main.html';
                        }
                        else{
                            console.log('DB not found')
                        }
                   })
                   .catch((err) => {
                        console.log(err);
                   })
                })
                .catch((error) => {
                    const errorCode = error.code;
                    const errorMessage = error.message;
                });
        })
    }
}

// function encrypt(text, key) {
//     var iv = crypto.getRandomValues(16);
//     var cipher = crypto.createCipheriv("AES-256-CBC", key, iv);
//     var encrypted = cipher.update(text);
//     encrypted = encrypted.concat(cipher.final());
//     return iv.concat(encrypted);
//   }
  
//   function decrypt(encrypted, key) {
//     var iv = encrypted.slice(0, 16);
//     var cipher = crypto.createDecipheriv("AES-256-CBC", key, iv);
//     var decrypted = cipher.update(encrypted.slice(16));
//     decrypted = decrypted.concat(cipher.final());
//     return decrypted;
//   }

