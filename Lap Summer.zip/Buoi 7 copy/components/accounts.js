import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getDatabase, set, ref, get, child, query, equalTo } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";
import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

export class Accounts {
    render() {
        const firebaseConfig = {
            apiKey: "AIzaSyBsG4juRDaBwFwuABPTXbavgyIkq0hkHaU",
            authDomain: "kimo-36593.firebaseapp.com",
            databaseURL: "https://kimo-36593-default-rtdb.asia-southeast1.firebasedatabase.app",
            projectId: "kimo-36593",
            storageBucket: "kimo-36593.appspot.com",
            messagingSenderId: "778449637560",
            appId: "1:778449637560:web:94acb9b6982bbd7fb3644d",
            measurementId: "G-PB3QSNVEND"
        };
        // Initialize Firebase
        const app = initializeApp(firebaseConfig);
        const database = getDatabase(app);
        const auth = getAuth();
        const user = userCredential.user;
        const usersRef = ref(database, 'users');
        get(usersRef)
            .then((snap) => {
                if (snap.exists()) {
                    console.log(snap.exists());
                }
                else {
                    console.log('DB not found')
                }
            })
            .catch((err) => {
                console.log(err);
            })
    }
}